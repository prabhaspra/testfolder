package dataPack;



	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.util.Scanner;

	public class TestConnect12 
	{
	
		public static void main(String[] args) throws Exception
		{
			int id,phone;
			String name,adress;  

			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Customer Details.....");
			
			id = sc.nextInt();
			name = sc.next();
			adress = sc.next();
			phone = sc.nextInt();
			
			Class.forName("org.h2.Driver");
			Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
			PreparedStatement pst = con.prepareStatement("insert into customervalues values(?,?,?,?)");
			
			pst.setInt(1,id);
			pst.setString(2, name);
			pst.setString(3, adress);
			pst.setInt(4, phone);
			
			pst.executeUpdate();
			
			pst.close();
			con.close();
			
			System.out.println("DATA IS ADDED.....");
		}

	}


