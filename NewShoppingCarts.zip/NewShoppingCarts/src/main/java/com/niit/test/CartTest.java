package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CartDAO;
import com.niit.model.Cart;



public class CartTest 
{

	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		System.out.println("success");
		Cart cart=(Cart) context.getBean("cart");
		
		
		cart.setPrice(55000);
		cart.setProduct_id("c3");
		cart.setQuantity(1);
		cart.setStatus("240pxl");
		cart.setUser_id("03" );
		
		cartDAO.addCart(cart);
	}

}
