package com.niit.dao;

import com.niit.model.Category;



public interface CategoryDAO 
{
   public void addCategory(Category category);
    
}
