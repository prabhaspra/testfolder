package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity 
@Table(name = "supplier")
@Component
public class Supplier
{
	@Id
	private String S_id;
	
	@NotEmpty(message = "please enter Name")
	private String S_name;
	
	@NotEmpty(message = "please enter Address")
	private String S_address;
	
	@NotEmpty(message = "please enter Phone no")
	private String S_phone;

	public String getS_id() {
		return S_id;
	}

	public void setS_id(String s_id) {
		S_id = s_id;
	}

	public String getS_name() {
		return S_name;
	}

	public void setS_name(String s_name) {
		S_name = s_name;
	}

	public String getS_address() {
		return S_address;
	}

	public void setS_address(String s_address) {
		S_address = s_address;
	}

	public String getS_phone() {
		return S_phone;
	}

	public void setS_phone(String s_phone) {
		S_phone = s_phone;
	}

	
	
}