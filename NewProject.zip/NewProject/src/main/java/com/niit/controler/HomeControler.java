package com.niit.controler;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.UserDAO;
import com.niit.model.User;


@Controller
public class HomeControler 
{
	@Autowired
	UserDAO userDAO;
	
	
	@RequestMapping("/")
	public String getlanding()
	{
		return "index";
	}
	@RequestMapping("register")
	public ModelAndView register(Model m)
	{
		m.addAttribute("user", new User());
		ModelAndView mv = new ModelAndView("signUp");
		return mv;
	}
	
	@RequestMapping(value="/register/add", method=RequestMethod.POST)
	public String addUser(Model model, @Valid @ModelAttribute("user") User user, BindingResult result, HttpServletRequest request)
	{
		userDAO.addUser(user);
		ModelAndView mv = new ModelAndView("/");
		mv.addObject("success","REGISTRATION IS SUCCESSFULL");
		return "redirect:/";
	}
	
	@RequestMapping("login")
	public String getlogin()
	{
		return "login";
	}
	
	
}
