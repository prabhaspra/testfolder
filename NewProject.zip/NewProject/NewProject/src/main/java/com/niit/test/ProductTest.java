package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.ProductDAO;
import com.niit.model.Product;

public class ProductTest
{
	public static void main(String[]args)
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();

		ProductDAO productDAO=(ProductDAO) context.getBean("productDAO");
		System.out.println("success");
		
		Product product=(Product)context.getBean("product");
		
		
		product.setP_id("01");
		product.setP_name("tmh");
		product.setP_price(200);
		product.setP_description("gedt");
		product.setCategory_id("900");
		product.setSupplier_id("87560");
		
		productDAO.addProduct(product);
	}
}