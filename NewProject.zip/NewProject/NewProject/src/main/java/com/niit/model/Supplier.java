package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity 
@Table(name = "supplier")
@Component
public class Supplier
{
	@Id
	private String s_id;
	
	@NotEmpty(message = "please enter Name")
	private String s_name;
	
	@NotEmpty(message = "please enter Address")
	private String s_address;
	
	@NotEmpty(message = "please enter Phone no")
	private String s_phone;

	public String gets_id() {
		return s_id;
	}

	public void setS_id(String s_id) {
		this.s_id = s_id;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_address() {
		return s_address;
	}

	public void setS_address(String s_address) {
		this.s_address = s_address;
	}

	public String getS_phone() {
		return s_phone;
	}

	public void setS_phone(String s_phone) {
		this.s_phone = s_phone;
	}

	
	
}