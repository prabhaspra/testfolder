package com.niit.controler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class HomeControler 
{
	@RequestMapping("/")
	
	
	public String getlanding()
	{
		return "index";
	}
	@RequestMapping("register")
	public String getregister()
	{
		return "signUp";
	}
	@RequestMapping("login")
	public String getlogin()
	{
		return "login";
	}
}
