package testPack;

public class Employee 
{
	int id, phoneNo;
	public void addEmp()
	{
		id=34;
		phoneNo=3546;
	}
	public void printEmp(int salary)
	{
		System.out.println(" Employee id is:"+id);
		System.out.println("Employee phone no is:"+phoneNo);
		System.out.println("Employee salary is:"+salary);
	}
	public void des(String name,int phoneNo)
	{
		System.out.println("Employee name is:"+name);
		System.out.println("Employee des:"+phoneNo);
	}
public static void main(String[]args)
{
Employee emp=new Employee();
emp.addEmp();
emp.printEmp(1000);
emp.des("praveen",24347);
}
}
