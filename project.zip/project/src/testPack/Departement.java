package testPack;

public class Departement 
{
String departementAddress;	
	public void addDep()
	{
		departementAddress="Malleshwarm";
	}
	public void printDep(int id)
	{
		System.out.println("Departement address is:"+departementAddress);
		System.out.println("Employee id is :"+id );
	}
	public void des(String name,int number)
	{
		System.out.println("Departement name is:"+name);
		System.out.println("Departement no is:"+number);
		
	}
public static void main(String[] args)s
{
	
	Departement dep=new Departement();
	dep.addDep();
	dep.printDep(200);
	dep.des("praveen", 54347);
		}


}