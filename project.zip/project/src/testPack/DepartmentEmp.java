package testPack;

public class DepartmentEmp 
{
String dname;

public String getDname()
{
	return dname;
}

public void setDname(String dname) 
{
	this.dname = dname;
}
 public static void main(String[]args)
 {
   DepartmentEmp depex=new DepartmentEmp();
 Employee emp=new Employee();
 depex.setDname("NIIT");
 String n=depex.getDname();
 emp.des("prav", 89528);
 
 
 Employee emp1=new Employee();
 depex.setDname("NIIT");
 String n1=depex.getDname();
 emp1.des("rah", 895858);
 
 Employee emp2=new Employee();
 depex.setDname("NIIT");
 String n2=depex.getDname();
 emp2.des("sach", 89213418);


 }
}
