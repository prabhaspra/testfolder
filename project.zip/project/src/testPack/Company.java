package testPack;

public class Company 
{
	String dname;
	
	
public String getDname()
{
		return dname;
	}


	public void setDname(String dname) 
	{
		this.dname = dname;
	}


public static void main(String[]args)
	{
	Company com=new Company();
	Departement dep=new Departement();
	com.setDname("Tally");
String n=com.getDname();
dep.des(n,345437 );
}
}